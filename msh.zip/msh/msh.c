/*
Name: Anusha Majeed
ID: 1001582645
*/

#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <signal.h>

#define WHITESPACE " \t\n"      /* We want to split our command line up into tokens
                                   so we need to define what delimits our tokens.
                                   In this case  white space
                                   will separate the tokens on our command line */

#define MAX_COMMAND_SIZE 255    // the maximum command size

#define MAX_NUM_ARGUMENTS 11    // mav shell only supports 10 arguments

#define MAX_HISTORY_LENGTH 15   // maximum number of commands to store in history

// command history is held in linked list
// each node points to a new/recent command while the head points to the oldest/first command 
	typedef struct node 
	{
		pid_t pid;
		char cmd[MAX_COMMAND_SIZE];
		struct node *next;
	}
	node;
	
	/* 	history is printed
	if num = 1 commands will be printed
	if num = 0 prints PIDs of commands which spawned child processes */
void printHistory(node *head, int num) 
{
    if (head == NULL) //history is empty
	{
		return; // does nothing
	}
	
    int i = 0;
    node *iter = head;
    while (iter != NULL)
	{
        // prints command string
        if (num) printf("%d: %s", i++, iter->cmd);

        // prints pid if non zero value
        if (!num && iter->pid) printf("%d: %d\n", i++, iter->pid);

        // iterate over linked list
        iter = iter->next;
    }
}

/* 	a new command is stored in the history list
	which starts at the head since it is the first command
	when adding a new command, if the length of history = MAX_HISTORY_LENGTH 
	then the oldest history command is freed and the head will point to the second oldest 
	to allow the function to modify the head, it is passed as a double pointer */

void saveCommand(node **head, char *cmd, int pid)
 {

    // set up the new node with its own memory location
    node *new = (node*) malloc(sizeof(node));
    strcpy(new->cmd, cmd);  // command string is copied into node memory
    new->pid = pid;         // copy pid
    new->next = NULL;       // clears junk
    
    // if head is NULL, then history is empty
    // point head to new entry
    if (*head == NULL)
	{
		*head = new;
	}
    else  // else, add new element to the end
	{ 
        int length = 1; //start at 1 because 0 is delt with in the if part
        node *iter = *head;
        
        // traverse the list & count entries
        while (iter->next != NULL) 
		{
            iter = iter->next;
            length++;
        }

        // add the new entry to end of the list
        iter->next = new;

        if (length == MAX_HISTORY_LENGTH)
		{
            node *new_head = (*head)->next; // save the second oldest command
            free(*head);                    // delete oldest command
            *head = new_head;               // reassign head
        }
    }
}


/*	gets a command from history , the n is the number 
	printed next to the command printed by printHistory
	returns a pointer to the designated command  */
char *getCommand(node *head, int n)
{

    if (head == NULL)
	{
		return NULL; // does nothing if history is empty
	}
    
    int i = 0;
    node *iter = head;

    // command string is copied into its own memory and is then freed after use
    char *cmd = (char*) malloc(MAX_COMMAND_SIZE);

    // loop through history stop when the appropriate command is found
    while (iter != NULL) 
	{
        if (i++ == n) 
		{
            strcpy(cmd, iter->cmd);
            return cmd;
        }
        iter = iter->next;
    }
    // if the loop makes it through the list, n was not found
    return NULL;
}

int main() 
{

	// cmd_str accepts input and is overwritten each iteration of the while loop
	char *cmd_str = (char*) malloc(MAX_COMMAND_SIZE);

	// head will always point to the oldest command in history
	node *head = NULL;

	while(1)
	{

		// Print out the msh prompt
		printf ("[msh] >> ");

		/* Read the command from the commandline.  The
		   maximum command that will be read is MAX_COMMAND_SIZE
		   This while command will wait here until the user
		   inputs something since fgets returns NULL when there
		   is no input */
		while(!fgets(cmd_str, MAX_COMMAND_SIZE, stdin));
    
		// when a blank is entered msh prompt is printed again
		if (cmd_str[0] == '\n')
		{
			continue;
		}
    
		// find command from history
		if (cmd_str[0] == '!') 
		{

			// convert string to integer 
			int n = atoi(&cmd_str[1]);

			// store the returned pointer so that it can be freed
			char *cmd = getCommand(head, n);

			// NULL means command was not found
			if (cmd == NULL)
			{
				printf("Command not in history.\n\n");
				continue;
			}

			// place the command we got into cmd_str
			strcpy(cmd_str, cmd);

			// free the string pointed to by cmd
			free(cmd);
		}

		// Parse input
		char *token[MAX_NUM_ARGUMENTS];
		int   token_count = 0;                                 
                                                           
		// Pointer to point to the token parsed by strsep
		char *argument_ptr;                                         
		char *working_str  = strdup(cmd_str);                

		/* we are going to move the working_str pointer so
		   keep track of its original value so we can deallocate
		   the correct amount at the end */
		char *working_root = working_str;

		// Tokenize the input strings with whitespace used as the delimiter
		while (((argument_ptr = strsep(&working_str, WHITESPACE)) != NULL) && (token_count<MAX_NUM_ARGUMENTS)) 
		{
			token[token_count] = strndup(argument_ptr, MAX_COMMAND_SIZE);
			if(strlen(token[token_count]) == 0 ) 
			{
				token[token_count] = NULL;
			}

			token_count++;
		}

		free(working_root);

		//exit/quit program
		if (strcmp(token[0], "exit") == 0 || strcmp(token[0], "quit") == 0) 
		{
			exit(0);
		}

		// change directory
		if (strcmp(token[0], "cd") == 0) 
		{
			saveCommand(&head, cmd_str, 0);

			//if no arguments go to home directory
			if (token[1] == NULL) 
			{
				chdir(getenv("HOME")); 
			}
			else if (token[2] != NULL) // too many arguments
			{
				printf("cd: too many arguments\n\n");
			}
			else 
			{
				chdir(token[1]);
			}
		}

		// history command 
		else if (strcmp(token[0], "history") == 0) 
		{

			saveCommand(&head, cmd_str, 0);

			// too many arguments
			if (token[1] != NULL)
			{
				printf("history: too many arguments\n\n");
			}
			else 
			{
				printHistory(head, 1); // pass 1 to print command strings
			}
		}

		//showpids command 
		else if (strcmp(token[0], "showpids") == 0) 
		{

			saveCommand(&head, cmd_str, 0);

			// too many arguments
			if (token[1] != NULL) 
			{
				printf("listpids: too many arguments\n\n");
			}
			else 
			{
				printHistory(head, 0); // pass 0 to print PIDs
			}
		}
		// all other commands handled by fork, wait, exec
		else 
		{

			pid_t pid;
			int status;

			pid = fork();

			// fork failed
			if (pid < 0) printf("fork failed\n");

			// child process    
			else if (pid == 0) 
			{
				// if execvp() returns a nonzero value, it failed
				if (execvp(token[0], token)) 
				{
					printf("%s: Command not found.\n\n", token[0]);
					exit(1);
				}
			}
			// parent process
			else 
			{
				// in the parent process, pid stores the PID of the child spawned
				saveCommand(&head, cmd_str, pid);
				while (wait(&status) != pid); // wait for child process to complete
			}
		}
	}
	return 0;
}
