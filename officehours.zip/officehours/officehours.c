/*
Name: Anusha Majeed
ID: 1001582645
*/
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>


#define MAX_SEATS 3        // Number of seats in the professor's office 
#define professor_LIMIT 10 // Number of students the professor can help before he needs a break 
#define MAX_STUDENTS 1000  // Maximum number of students in the simulation 

#define CLASSA 0
#define CLASSB 1
#define ON_REST 1
#define RESET -1
#define NADA 0

/* TODO */
/* Add your synchronization variables here */
pthread_mutex_t professor_break_mutex;
pthread_mutex_t classA_mutex;
pthread_mutex_t classB_mutex;

sem_t seats;
pthread_cond_t cameIn;
pthread_cond_t kickedOut;

/* Basic information about simulation.  They are printed/checked at the end
* and in assert statements during execution.
*
* You are responsible for maintaining the integrity of these variables in the
* code that you develop.
*/

static int studentsInOffice;
static int classAinOffice;
static int classBinOffice;
static int studentsSinceBreak = 0;
static int classToFollow;
static int aInLine;
static int bInLine;
static int profRest;
static int counter;
static int counterATogether;
static int counterBTogether;


typedef struct
{
	int arrivalTime;  // time between the arrival of this student and the previous student
	int questionTime; // time the student needs to spend with the professor
	int studentID;
	int class;
} studentInfo;

/* Called at beginning of simulation.
* TODO: Create/initialize all synchronization
* variables and other global variables that you add.
*/
static int initialize(studentInfo *si, char *filename)
{
	pthread_mutex_init(&professor_break_mutex, NULL);
	pthread_mutex_init(&classA_mutex, NULL);
	pthread_mutex_init(&classB_mutex,NULL);

	sem_init(&seats,0,3);

	studentsInOffice = 0;
	classAinOffice = 0;
	classBinOffice = 0;
	studentsSinceBreak = 0;
	classToFollow = -1; //Office is empty
	profRest = 0;
	counter = 0;
	aInLine = 0;
	bInLine = 0;
	counterATogether = 0;
	counterBTogether = 0;

	/* Read in the data file and initialize the student array */
	FILE *fp;

	if((fp=fopen(filename, "r")) == NULL)
	{
		printf("Cannot open input file %s for reading.\n", filename);
		exit(1);
	}

	int i = 0;
	while ( (fscanf(fp, "%d%d%d\n", &(si[i].class), &(si[i].arrivalTime),
	&(si[i].questionTime))!=EOF) && i < MAX_STUDENTS )
	{
		i++;
	}

	fclose(fp);
	return i;
}

/* Code executed by professor to simulate taking a break
* You do not need to add anything here.
*/
static void takeBreak()
{
	printf("The professor is taking a break now.\n");
	sleep(5);
	assert( studentsInOffice == 0 );
	studentsSinceBreak = 0;
}

/* Code for the professor thread. This is fully implemented except for synchronization
* with the students.  See the comments within the function for details.
*/
/*
This function switches the classes depending on the conditions. It switches 
what threads will continue and will give the professor a break if more than
10 students have entered
*/
void *professorThread(void *junk)
{
	printf("The professor arrived and is starting his office hours\n");

	/* Loop while waiting for students to arrive. */
	while (1)
	{

		/* TODO */                                              
		/*Handles students request. Students are admitted based on 
		/*number of seats available, which class a student is in, and
		/*whether the professor needs a break. */

		if (classToFollow == CLASSB && bInLine == 0)
		{
			classToFollow = -1;
		}
		else if (classToFollow == CLASSA && aInLine == 0)
		{
			classToFollow = -1;
		}
		counter++;
		if (counterATogether == 5 || counterBTogether == 5)
		{
			if (classToFollow == CLASSA)
			{
				classToFollow = CLASSB;
			}
			else
			{
				classToFollow = CLASSA;
			}
			counter++;
		}
		else if (classToFollow == RESET)
		{
			if (classAinOffice > 0)
			{
				classToFollow = CLASSA;
			}
			else
			{
				classToFollow = CLASSB;
			}
		}

		if (studentsSinceBreak == 9)
		{
			profRest = ON_REST;
			pthread_mutex_lock(&professor_break_mutex);
			while(studentsInOffice != 0)
			{
			}
			takeBreak();
			pthread_mutex_unlock(&professor_break_mutex);
			profRest--;
		}
	}
	pthread_exit(NULL);
}


/* Code executed by a class A student to enter the office.
* You have to implement this.  Do not delete the assert() statements,
* but feel free to add your own.
*/
/*
A class A student enters causing their thread to be locked. While it does
not fall into the conditions the thread will unlock allowing another student
to enter . It will lock again and recheck the conditions. Once it is out of the 
while loop, the sem_wait will run and wait for a new student from class A to 
take a seat. It will increment and unlock the threads that came into class A. 
*/
void classAEnter()
{

	/* TODO */
	/* Request permission to enter the office.  You might also want to add  */
	/* synchronization for the simulations variables below                  */
	/*  YOUR CODE HERE.                                                     */

	pthread_mutex_lock(&classA_mutex);
	aInLine++;
	while(((!((studentsInOffice < MAX_SEATS && classToFollow == RESET || classToFollow == CLASSA) &&
		classBinOffice == NADA && counterATogether < 5 && studentsSinceBreak < 10 ))))
		{
			pthread_mutex_unlock(&classA_mutex);
                      //  usleep(1000);
			pthread_mutex_lock(&classA_mutex);

		}
	sem_wait(&seats);
	aInLine--;
	studentsInOffice += 1;
	classAinOffice += 1;
	studentsSinceBreak += 1;
	counterATogether += 1;
	counterBTogether = 0;
	pthread_mutex_unlock(&classA_mutex);

}

/* Code executed by a class B student to enter the office.
* You have to implement this.  Do not delete the assert() statements,
* but feel free to add your own.
*/
/*
A class B student enters causing their thread to be locked. While it does
not fall into the conditions the thread will unlock allowing another student
to enter . It will lock again and recheck the conditions. Once it is out of the 
while loop, the sem_wait will run and wait for a new student from class B to 
take a seat. It will increment and unlock the threads that came into class B. 
*/
void classBEnter()
{

	/* TODO */
	/* Request permission to enter the office.  You might also want to add  */
	/* synchronization for the simulations variables below                  */
	/*  YOUR CODE HERE.                                                     */

	pthread_mutex_lock(&classA_mutex);
	bInLine++;
	while(((!((classToFollow == RESET || classToFollow == CLASSB) && studentsInOffice < MAX_SEATS &&
		classAinOffice == NADA && counterBTogether < 5 && studentsSinceBreak < 10 ) )))
		{
			pthread_mutex_unlock(&classA_mutex);
			pthread_mutex_lock(&classA_mutex);
		}

	sem_wait(&seats);
	bInLine--;
	studentsInOffice += 1;
	classBinOffice += 1;
	counterBTogether += 1;
	studentsSinceBreak += 1;
	counterATogether = 0;
	pthread_mutex_unlock(&classA_mutex);

}

/* Code executed by a student to simulate the time he spends in the office asking questions
* You do not need to add anything here.
*/
static void askQuestions(int t)
{
	sleep(t);
}


/* Code executed by a class A student when leaving the office.
* You need to implement this.  Do not delete the assert() statements,
* but feel free to add as many of your own as you like.
*/
/*
This function locks the thread that is leaving and decrements so the A student
in line gets dequeued. sem post_post will signal the threads that the student
left and will be unlocked. 
*/
static void classALeave()
{
	pthread_mutex_lock(&classB_mutex);
	studentsInOffice -= 1;
	classAinOffice -= 1;
	sem_post(&seats);
	pthread_mutex_unlock(&classB_mutex);
}

/* Code executed by a class B student when leaving the office.
* You need to implement this.  Do not delete the assert() statements,
* but feel free to add as many of your own as you like.
*/
/*
This function locks the thread that is leaving and decrements so the B student
in line gets dequeued. sem post_post will signal the threads that the student
left and will be unlocked. 
*/
static void classBLeave()
{
	pthread_mutex_lock(&classB_mutex);
	studentsInOffice -= 1;
	classBinOffice -= 1;
	sem_post(&seats);
	pthread_mutex_unlock(&classB_mutex);

}

/* Main code for class A student threads.
* You do not need to change anything here, but you can add
* debug statements to help you during development/debugging.
*/
void* classAStudent(void *si)
{
	studentInfo *s_info = (studentInfo*)si;

	/* enter office */
	classAEnter();

	printf("Student %d from class A enters the office\n", s_info->studentID);

	assert(studentsInOffice <= MAX_SEATS && studentsInOffice >= 0);
	assert(classAinOffice >= 0 && classAinOffice <= MAX_SEATS);
	assert(classBinOffice >= 0 && classBinOffice <= MAX_SEATS);
	assert(classBinOffice == 0 );

	/* ask questions  --- do not make changes to the 3 lines below*/
	printf("Student %d from class A starts asking questions for %d minutes\n", s_info->studentID, s_info->questionTime);
	askQuestions(s_info->questionTime);
	//printf("%d\n",studentsSinceBreak );

	printf("Student %d from class A finishes asking questions and prepares to leave\n", s_info->studentID);

	/* leave office */
	classALeave();

	printf("Student %d from class A leaves the office\n", s_info->studentID);

	assert(studentsInOffice <= MAX_SEATS && studentsInOffice >= 0);
	assert(classBinOffice >= 0 && classBinOffice <= MAX_SEATS);
	assert(classAinOffice >= 0 && classAinOffice <= MAX_SEATS);

	pthread_exit(NULL);
}

/* Main code for class B student threads.
* You do not need to change anything here, but you can add
* debug statements to help you during development/debugging.
*/
void* classBStudent(void *si)
{
	studentInfo *s_info = (studentInfo*)si;

	/* enter office */
	classBEnter();

	printf("Student %d from class B enters the office\n", s_info->studentID);

	assert(studentsInOffice <= MAX_SEATS && studentsInOffice >= 0);
	assert(classBinOffice >= 0 && classBinOffice <= MAX_SEATS);
	assert(classAinOffice >= 0 && classAinOffice <= MAX_SEATS);
	assert(classAinOffice == 0 );

	printf("Student %d from class B starts asking questions for %d minutes\n", s_info->studentID, s_info->questionTime);
	askQuestions(s_info->questionTime);
	//printf("%d\n",studentsSinceBreak );

	printf("Student %d from class B finishes asking questions and prepares to leave\n", s_info->studentID);

	/* leave office */
	classBLeave();

	printf("Student %d from class B leaves the office\n", s_info->studentID);

	assert(studentsInOffice <= MAX_SEATS && studentsInOffice >= 0);
	assert(classBinOffice >= 0 && classBinOffice <= MAX_SEATS);
	assert(classAinOffice >= 0 && classAinOffice <= MAX_SEATS);

	pthread_exit(NULL);
}

/* Main function sets up simulation and prints report
* at the end.
*/
int main(int nargs, char **args)
{
	int i;
	int result;
	int studentType;
	int numStudents;
	void *status;
	pthread_t professor_tid;
	pthread_t student_tid[MAX_STUDENTS];
	studentInfo s_info[MAX_STUDENTS];

	if (nargs != 2)
	{
		printf("Usage: officehour <name of inputfile>\n");
		return EINVAL;
	}

	numStudents = initialize(s_info, args[1]);
	if (numStudents > MAX_STUDENTS || numStudents <= 0)
	{
		printf("Error:  Bad number of student threads. "
		"Maybe there was a problem with your input file?\n");
		return 1;
	}

	printf("Starting officehour simulation with %d students ...\n",
	numStudents);

	result = pthread_create(&professor_tid, NULL, professorThread, NULL);

	if (result)
	{
		printf("officehour:  pthread_create failed for professor: %s\n", strerror(result));
		exit(1);
	}

	for (i=0; i < numStudents; i++)
	{

		s_info[i].studentID = i;
		sleep(s_info[i].arrivalTime);

		//studentType = random() % 2;
		studentType = rand() % 2;

		if (studentType == CLASSA)
		{
			result = pthread_create(&student_tid[i], NULL, classAStudent, (void *)&s_info[i]);
		}
		else // studentType == CLASSB
		{
			result = pthread_create(&student_tid[i], NULL, classBStudent, (void *)&s_info[i]);
		}

		if (result)
		{
			printf("officehour: thread_fork failed for student %d: %s\n",
			i, strerror(result));
			exit(1);
		}
	}

	/* wait for all student threads to finish */
	for (i = 0; i < numStudents; i++)
	{
		pthread_join(student_tid[i], &status);
	}

	/* tell the professor to finish. */
	pthread_cancel(professor_tid);

	printf("Office hour simulation done.\n");

	return 0;
}
