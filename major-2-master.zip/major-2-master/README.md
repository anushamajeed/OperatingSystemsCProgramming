# Major 2

## Contributors
### Anusha Majeed aam0524

- cd command
- io redirection
### Eric Phegley erp0103
- myhistory command
- signal handling
### Michael Andy McDowall mam1214
- path
- alias
- batch implementation
- semicolon behavior
- tokenizing
- part of cli loop

### Dinh Thang Nguyen dtn0086
- exit command
- pipeline operation

## Design Overview
The "myhistory" command uses a linked list of structs to store the user's history. Each command from the user is stored as a string in 1 field, and as an int in 2nd field. The int is used to keep track of the number associated with each command (so that the '-e' flag can find it) and also to help the linked list overwrite itself when there are more than 20 commands.

Signal handling is partially complete. The program will handle a SIGINT (CTRL + C) in a subprocess that would make sense, like after a 'sleep' command. The user who implemented this was unable to find a solution for the SIGTSTP (CTRL + Z) signal.

Path and alias handling are both done by storing the records in the memory of the program. For paths, the PATH variable is replaced whenever a call is made, and the old PATH is reloaded after that call is finished. For aliases, after tokenization but before execution, any token matching an alias is replaced with the command saved to that alias. This is similar to "expanding" variables in bash. Note that aliases are not recursive, as this was deemed outside of the scope of this project, having not been mentioned in the project specification.

The "cd" command implements the chdir function to change the directory while also printing out the current working directory. The path parameter where the directory is changed to.

I/O redirection is done using a redirection operator that allows the user to specify the input or output data to be redirected.

The "exit" command implement the exit() system call to exit out of the shell by checking for command 'exit'.

Pipelining is done by checking for the "|" symbol and how many there are and then parse them into commands. The pipeline function will use the pipe() system call to connect the standard output of the first command to the standard input of the second command. If it is a 3 commands chained then the function will do the same thing with the extra step of connect the standard output of the second command to the standard input of third command.

## Known Bugs
#### Major(Affect Program)
- a CTRL + Z signal inside any process will be ignored. The correct functionality was not implemented.
#### Minor(Format/Style)
- myhistory numbers reset to 1 when history has been cleared, instead of what the lowest number was in the case of (>20) entries.
- permissions problems may cause searching some directories to fail, but the command will still complete without a fatal error.
## Compiling Instructions
On the terminal, use the command make and then compile with the command ./major2

