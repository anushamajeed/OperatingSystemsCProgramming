#ifndef _major2_
#define _major2_

#include "history.h"
#include "alias.h"
#include "path.h"
#include "exit.h"
#include "ioredirection.h"
#include "history.h"
#include "cd_command.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

char* myhistory(char* userargs[512], char cmdentry[512], int alreadydoneit);
char** tokenize(char* str, int* argc);
void exec_cmd(char** argv, int argc);
char** insert_tokens(char** tokens, int tc, char** insert, int ic, int ins_idx);
char* stripspace(char* str);
// int cd(char *pathGiven);
// int prex(char const *, char const *);


#endif
