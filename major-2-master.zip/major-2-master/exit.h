#ifndef _exit_
#define _exit_

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>

int exitShell();

#endif
