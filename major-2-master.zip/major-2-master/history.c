#include "history.h"

void  printList(struct Entry* n){
	while(n != NULL){
		printf("[%d]: %s\n", n->Number, n->Command);
		n = n->next;
	}
}

void append(struct Entry** head, char* command){
	struct Entry* n = *head;
	struct Entry* newEntry = (struct Entry*)malloc(sizeof(struct Entry));
	strcpy(newEntry->Command, command);
	while(n->next != NULL){
		n = n->next;
	}
	newEntry->Number = n->Number + 1;
	n->next = newEntry;
}
void insert(struct Entry**head, char* command){
	struct Entry* n = *head;
	strcpy(n->Command, command);

}

void deleteEntry(struct Entry**head){
	struct Entry* deleted = *head;
	*head = deleted->next;
	//free(deleted);
	
}

void newEntry(struct Entry**head, char* command){
	struct Entry* n = (struct Entry*)malloc(sizeof(struct Entry));
	n->Number = 1;
	struct Entry* count = *head;

	int endNum;
	int numEntries = 0;
	if(*head == NULL){
		*head = n;
		insert(head, command);
	}
	else{
		int startNum = count->Number;
		while(count->next!=NULL){
			count = count->next;
		}
		endNum = count->Number;
		numEntries = endNum - startNum + 1;
		if(numEntries < 20){
			append(head, command);
		}
		else{
			deleteEntry(head);
			append(head, command);
		}
	}
}
void clearList(struct Entry**head){
	while(*head != NULL){
		deleteEntry(head);
	}
}

char* findCommand(struct Entry**head, int num){
	struct Entry* n = *head;
	char* notfound = "no command found";
	if(n != NULL){
		while(n != NULL){
			if((n->Number) == num){
				return n->Command;
			}
			else{
				n = n->next;
			}
		}
		return notfound;
	}
	return notfound;
}
