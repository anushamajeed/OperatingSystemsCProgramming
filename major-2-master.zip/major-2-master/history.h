
#ifndef _history_
#define _history_

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MYHISTORY_CMD "myhistory"
struct Entry{
	char Command[512];
	int Number;
	struct Entry* next;
};

void printList(struct Entry* n);
void append(struct Entry** head, char* command);
void insert(struct Entry** head, char* command);
void deleteEntry(struct Entry** head);
void newEntry(struct Entry** head, char* command);
void clearList(struct Entry** head);
char* findCommand(struct Entry** head, int num);

#endif