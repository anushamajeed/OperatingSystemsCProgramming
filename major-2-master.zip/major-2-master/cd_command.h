//Anusha Majeed aam0524 cd_command.h
#ifndef _cd_command_
#define _cd_command_

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CD_CMD "cd"

int cd(char *pathGiven[512]);
int prex(char const *, char const *);

#endif




