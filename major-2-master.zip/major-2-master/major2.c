#include "major2.h"

struct Entry* head = NULL;

void handler(int sig){
	int pidp = getpid();

	switch(sig){
		case SIGINT :
			printf("\n");
			kill(SIGINT, pidp);
	}

}

char* myhistory(char* userargs[512], char cmdentry[512], int alreadydoneit){
	char commandfound[512];
	if(userargs[1] == NULL){	//no flags
		if(alreadydoneit == 0){
			newEntry(&head, cmdentry);	//**call this after every successful command
		}
		printList(head);
		return "no";
	}
	else if(strcmp(userargs[1], "-e") == 0){	//execute command flag
		if(userargs[2] == NULL){
			printf("usage: myhistory <flag> <int> (if flag = '-e')\n");
			return "no";
		}
		strcpy(commandfound, findCommand(&head, atoi(userargs[2])));
		if(strcmp(commandfound, "no command found") == 0){
			printf("Error: %s\n", commandfound);
			return "no";
		}
		else{
			newEntry(&head, cmdentry);
			return strdup(commandfound);
		}
	}
	else if(strcmp(userargs[1], "-c") == 0){	//clear history flag
		if(userargs[2] != NULL){
			printf("usage: myhistory <flag> (if flag = '-c')... %s was ignored\n", userargs[2]);
		}
		clearList(&head);
		return  "no";
	}
	else{
		printf("unrecognized flag %s\n", userargs[1]);
		return "no";
	}
}

int main(int argc, char* argv[]){
	signal(SIGINT, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	char command[512];	//original string command from user
	char *cmdpipe1[512], *cmdpipe2[512], *cmdpipe3[512]; // used for pipeline command
	char cmdentry[512];	//used for myhistory inserting
	char *previouscommand = "no";
	int entrycounter = 0;
	int createentry = 0;
	bool nothistory = true;
	bool exitStatus = false;
	int i = 0;
	char** userargs;	//the user's command separated by spaces, similar to argv
	userargs = (char**)malloc(128*sizeof(char*));
	for(int i = 0; i < 128; i++)
		userargs[i] = (char*)malloc(512*sizeof(char));
	init_alias();
	init_path();

	FILE* in_channel = stdin;
	if(argc >= 2)
	{
		in_channel = fopen(argv[1], "r");
		if(in_channel == NULL) {
			perror("Error opening file");
			return(-1);
		}
	}

	char* endloop = 1;
	while((endloop != NULL && argc >= 2) || argc == 1){
		entrycounter = 0;
		if(argc == 1) //if using terminal
			printf("Enter command: ");
		endloop = fgets(command, 512, in_channel);
		if(endloop == NULL && argc >= 2)
			continue;

		if(strcmp(command, "\n") == 0){
			continue;
		}
		int len = strlen(command);
		if(len > 0 && command[len - 1] == '\n'){ //removes a \n from fgets
			command[len - 1] = '\0';
		}
		strcpy(cmdentry, command);	//used for myhistory inserting
		char delim[] = ";";
		char *p = (char*) malloc(sizeof(char*));
		if(p == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}
		int uac = 1;
		userargs[0] = strtok(command, delim);
		while((p = strtok(NULL, delim)) && p != NULL)
		{
			strcpy(userargs[uac], p);
			uac++;
		}

		while(i < uac)
		{
			if(i > 0){
				createentry = 1;
			}
			//Test to see if there's a pipe symbol (|) in the command
			char* strpiped[3];
			int piped = 0;
			piped = parsePipe(command, strpiped);

			int argca = 0;
			char** argva;
			if(strcmp(previouscommand, "no") == 0){
				argva = tokenize(stripspace(userargs[i]), &argca);
				i++;
			}
			else{
				argva = tokenize(stripspace(previouscommand), &argca);
				i++;
			}

			// Aliasing
			if(strcmp(argva[0], "alias") != 0) { // Don't alias on 'alias' cmd
				for(int tokeni = 0; tokeni < argca; tokeni++)
				{
					for(int aliasi = 0; aliasi < alias_len(); aliasi++)
					{
						if(strcmp(alias_at(aliasi), argva[tokeni]) == 0)
						{
							argva = insert_tokens(
								argva, argca,
								alias_translate(aliasi), aliasc(aliasi),
								tokeni
							);
							argca += aliasc(aliasi);
							tokeni += aliasc(aliasi);
							break;
						}
					}
				}
			}

			//userargs now serves the same purpose as argv (semicolons not accounted for)
			if(strcmp(argva[0], MYHISTORY_CMD) == 0){
				if((strcmp(previouscommand, "no") == 0) && createentry == 0){
					previouscommand = myhistory(argva, cmdentry, 0);
					nothistory = false;
					entrycounter++;
				}
				else if((strcmp(previouscommand, "no") == 0) && createentry == 1){
					previouscommand = myhistory(argva, cmdentry, 1);
					nothistory = false;
					entrycounter++;
				}
				else{
					strcpy(previouscommand, myhistory(argva, previouscommand, 1));
				}
			}
			else if(strcmp(argva[0], PATH_CMD) == 0)
			{
				previouscommand = "no";
				path(argva, argca);
			}
			else if(strcmp(argva[0], ALIAS_CMD) == 0)
			{
				previouscommand = "no";
				alias(argva, argca);
			}
			else if(strcmp(argva[0], CD_CMD) == 0)
			{
				previouscommand = "no";
				cd(argva);
			}
			else if (piped > 0)
			{
				if (piped == 2){
					parseSpace(strpiped[0], cmdpipe1);
					parseSpace(strpiped[1], cmdpipe2);
					execArgsPiped2(cmdpipe1, cmdpipe2);
				}
				else if (piped == 3){
					parseSpace(strpiped[0], cmdpipe1);
					parseSpace(strpiped[1], cmdpipe2);
					parseSpace(strpiped[2], cmdpipe3);
					execArgsPiped3(cmdpipe1, cmdpipe2, cmdpipe3);
				}
			}
			else if (strcmp(argva[0], "exit") == 0)
			{
				exitStatus = true;
			}	
			else
			{
				previouscommand = "no";
				exec_cmd(argva, argca);
			}
			if(nothistory == true && entrycounter == 0){
				newEntry(&head, cmdentry);
				entrycounter++;
			}
			if(strcmp(previouscommand, "no") != 0){
				i--;
			}
			nothistory = true;
		}
		if(exitStatus){
			exitShell();
		}
		createentry = 0;
		i = 0;
	}

	uninit_alias();
	uninit_path();
	return 0;
}

// exec_cmd executes the given arbitrary command, including alias and path operations.
void exec_cmd(char** argv, int argc)
{
	// Change path
	signal(SIGINT, &handler);
	char save_path[2048];
	char path[2048];
	strcpy(save_path, getenv("PATH"));
	strcpy(path, getenv("PATH"));
	if(strlen(path) > 0)
		strcat(path, ":");
	strcat(path, sprint_path());
	setenv("PATH", path, 1);

	// Null terminate
	char** argvtemp = malloc((argc+1)*sizeof(char*));
	for(int i = 0; i < argc+1; i++)
		argvtemp[i] = argv[i];
	argvtemp[argc] = NULL;

	// Exec
	int pid = fork();
	int ret = 1;
	if(pid == 0)
	{
		pid_t group = getpgrp();
		tcsetpgrp(0, group);
		if(execvp(argvtemp[0], argvtemp) == -1 )
		{
			printf("Command failed. Did you type it correctly?\n");
		}
		exit(0);
	}
	wait(NULL);

	// Cleanup
	setenv("PATH", save_path, 1);
}

// stripspace strips the leading and trailing spaces from a string
char* stripspace(char* str)
{
	char* ret = malloc(strlen(str)*sizeof(char));
	if(ret == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}

	int islead = 1;
	int retpos = 0;
	for(int i = 0; i < strlen(str); i++)
	{
		if(islead && str[i] == ' ')
			continue;
		islead = 0;
		ret[retpos] = str[i];
		retpos++;
	}
	ret[retpos] = '\0';

	int istrail = 1;
	for(int i = strlen(ret)-1; i >= 0; i--)
	{
		if(istrail && ret[i] == ' ')
		{
			ret[i] = '\0';
			continue;
		}
		istrail = 0;
		break;
	}

	return ret;
}

// insert_tokens replaces the token at ins_idx with the insert tokens
char** insert_tokens(char** tokens, int tc, char** insert, int ic, int ins_idx)
{
	char** ret = malloc((tc+ic)*sizeof(char*));
	if(ret == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}

	for(int i = 0; i < ins_idx; i++)
		ret[i] = tokens[i];
	
	for(int i = 0; i < ic; i++)
		ret[i+ins_idx] = insert[i];
	
	for(int i = ins_idx; i < tc; i++)
		ret[i+ic] = tokens[i+1];

	return ret;
}

// tokenize converts a string into array of strings delimited by spaces. argc is the size of this array.
char** tokenize(char* str, int* argc)
{
	char** ret = malloc(512*sizeof(char*));
	if(ret == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}
	char* buf = malloc(512*sizeof(char));
	if(buf == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}
	int bufi = 0, reti = 0;
	for(int i = 0; i < strlen(str); i++)
	{
		if(str[i] == ' ')
		{
			ret[reti] = buf;
			bufi=0;
			buf = malloc(512*sizeof(char));
			if(buf == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}
			reti++;
			continue;
		}
		buf[bufi] = str[i];
		bufi++;
	}
	buf[bufi] = '\0';
	ret[reti] = buf;

	*argc = reti+1;
	return ret;
}
