#include "alias.h"

#define START_CAP (2)
#define CAP_MULT (2)

//Postconds:
//Any string before length is non-null
//Any string before length is terminated by \0
char** __aliases;
// NOTE: INDIVIDUAL ALIAS COMMAND ARRAYS ARE NOT ALLOCATED
// THEY MUST BE ALLOCATED WHEN ADDED
char*** __aliasvals; //[aliasid][argid]*[chari]* *-> not allocated
int* __aliasc;
int __alias_length = 0;
int __alias_cap = START_CAP;
bool __alias_open = false;

int alias_len()
{
    return __alias_length;
}

char* alias_at(int i)
{
    return __aliases[i];
}

char** alias_translate(int i)
{
    return __aliasvals[i];
}

int aliasc(int i)
{
    return __aliasc[i];
}

int contains(char* str, char* ss)
{
    for(int i = 0; i < strlen(str); i++)
    {
        int found = 1;
        for(int j = 0; j < strlen(ss); j++)
        {
            if(str[i+j] != ss[j])
            {
                found = 0;
                break;
            }
        }

        if(found)
            return i;
    }
    return -1;
}

// alias takes in the raw cmd request, and performs as specified in the project statement.
// Returns:
// -2: On malformed command
// <0: On error
// 0: On success.
int alias(char* cmd[], int argc)
{
    // Guards
    if(argc == 0 || strcmp(cmd[0], ALIAS_CMD) != 0)
    {
        printf("ERROR: path() may have been called incorrrectly. the given command is %s, where path is expected.\n", cmd[0]);
        return -1;
    }

    if(argc == 1)
        printf("%s", sprint_alias());
    else if(strcmp(cmd[1], "-c") == 0)
        return rm_all_alias();
    else if(strcmp(cmd[1], "-r") == 0)
        return rm_alias(cmd[2]);
    else
    {
        //add TODO
        int c = argc;
        char* alias = malloc(512*sizeof(char));
        char** newcmd = parse_alias_cmd(cmd, &c, alias);
        if(newcmd == NULL)
            return -1;
        return add_alias(alias, newcmd, c);
    }
}

// init_alias performs memory initialization of alias impl, and should be called at shell startup
int init_alias()
{
    // aliases
    __aliases = (char**) malloc(__alias_cap*sizeof(char*));
    if(__aliases == NULL)
        printf("ERROR: failed to malloc (init_alias)\n");

    for(int i = 0; i < __alias_cap; i++)
    {
        __aliases[i] = (char*) malloc(ALIAS_LENGTH*sizeof(char*));
        if(__aliases[i] == NULL)
            printf("ERROR: failed to malloc (init_path)\n");
    }

    // aliasc
    __aliasc = (int*) malloc(__alias_cap*sizeof(int));

    // aliasvals
    __aliasvals = (char***) malloc(__alias_cap*sizeof(char***));
    if (__aliasvals == NULL)
        printf("ERROR: failed to malloc (init_alias)\n");

    __alias_open = true;
    return 0;
}

// uninit_path performs memory deallocation, and should be performed at shell stop
int uninit_alias()
{
    __alias_open = false;

    // aliases
    for(int i = 0; i < __alias_cap; i++)
        free(__aliases[i]);
    free(__aliases);

    // aliasvals
    for(int aliasi = 0; aliasi < __alias_cap; aliasi++)
    {
        for(int argi = 0; argi < __aliasc[aliasi] && aliasi < __alias_length; argi++)
            free(__aliasvals[aliasi][argi]);
        free(__aliasvals[aliasi]);
    }
    free(__aliasvals);

    // aliasc
    free(__aliasc);

    return 0;
}

// sprint_alias returns a newline spearated list of aliases
char* sprint_alias()
{
    // Guard
    if(!__alias_open)
        printf("ERROR: memory for alias has been deallocated.\n");
    
    // Determine Length.
    int sum = 0;
    for(int aliasi = 0; aliasi < __alias_length; aliasi++)
    {
        for(int argi = 0; argi < __aliasc[aliasi]; argi++)
        {
            sum += strlen(__aliasvals[aliasi][argi]);
        }
        sum += strlen(__aliases[aliasi]) + __aliasc[aliasi] + 4; //Extra for %s='%s'\n and spaces
    }
    sum++; //for \0

    char* ret = malloc(sum*sizeof(char));
    ret[0] = '\0';
    for(int aliasi = 0; aliasi < __alias_length; aliasi++)
    {
        strcat(ret, __aliases[aliasi]);
        strcat(ret, "='");
        for(int argi = 0; argi < __aliasc[aliasi]; argi++)
        {
            strcat(ret, __aliasvals[aliasi][argi]);
            strcat(ret, " ");
        }
        strcat(ret, "'\n");
    }

    return ret;
}

// // add_alias adds an alias to the shell
int add_alias(char* alias, char* cmd[], int cmdc)
{
    // Guard
    if(!__alias_open)
    {
        printf("ERROR: memory for path has been deallocated.\n");
        return -1;
    }
    //TODO: check error case vvvv
    // if(strlen(cmd) > ALIAS_MAX_LEN)
    // {
    //     printf("ERROR: length of given alias is more than PATH_MAX_LEN (%d > %d)\n", strlen(path), ALIAS_MAX_LEN);
    //     return -1;
    // }
    if(ensure_alias_cap(__alias_length+1) != 0)
    {
        printf("ERROR: failed to ensure path capacity\n");
        return -1;
    }

    // Copy cmd into cmd array
    __aliasvals[__alias_length] = (char**) malloc(cmdc*sizeof(char*));
    for(int i = 0; i < cmdc; i++)
        __aliasvals[__alias_length][i] = (char*) malloc(ALIAS_LENGTH*sizeof(char));
    for(int i = 0; i < cmdc; i++)
        strcpy(__aliasvals[__alias_length][i], cmd[i]);

    // Copy alias into alias array
    __aliases[__alias_length] = (char*) malloc(512*sizeof(char));
	if(__aliases[__alias_length] == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}
    strcpy(__aliases[__alias_length], alias);

    // Copy argc into aliasc array
    __aliasc[__alias_length] = cmdc;

   __alias_length++;

   return 0;
}

// rm_alias removes a alias from the shell.
// Return:
// <0: On error
// 0: On successful removal
// 1: If path was not found
int rm_alias(char* alias)
{
    // Guard
    if(!__alias_open)
    {
        printf("ERROR: memory for path has been deallocated.\n");
        return -1;
    }
    if(strlen(alias) > ALIAS_MAX_LEN)
    {
        printf("ERROR: length of given path is more than PATH_MAX_LEN (%d > %d)\n", strlen(alias), ALIAS_MAX_LEN);
        return -1;
    }

    // Find alias
    int index = -1;
    for(int i = 0; i < __alias_length; i++)
    {
        if(strcmp(alias, __aliases[i]) == 0)
        {
            index = i;
            break;
        }
    }

    // Alias wasn't found
    if(index == -1)
        return 1;
    
    // Remove path - aliasval
    for(int i = index; i < __alias_length-1; i++)
    {
        __aliasvals[i] = __aliasvals[i+1];
        __aliases[i] = __aliases[i+1];
        __aliasc[i] = __aliasc[i+1];
    }
    // Necessary to zero out second same pointer, otherwise free() twice will cause issues.
    __aliasvals[__alias_length-1] = NULL;
    __aliases[__alias_length-1] = NULL;
    __aliasc[__alias_length-1] = NULL;
    __alias_length--;

    return 0;
}

int rm_all_alias()
{
    __alias_length = 0;
}

// ensure_alias_cap ensures that there is len indexes allocated in all alias arrays
int ensure_alias_cap(int len)
{
    if(len <= __alias_cap)
        return 0;
    
    int newcap = __alias_cap*CAP_MULT;

    // Allocated bigger __aliasvals
    char*** newvals = (char***) malloc(newcap*sizeof(char***));
    if (newvals == NULL)
        printf("ERROR: failed to malloc\n");
    for(int aliasid = 0; aliasid < newcap; aliasid++)
    {
        newvals[aliasid] = (char**) malloc(newcap*sizeof(char**));
        if(newvals[aliasid] == NULL)
            printf("ERROR: failed to malloc (init_alias)\n");
        if(aliasid < __alias_length)
            newvals[aliasid] = __aliasvals[aliasid];
    }
    free(__aliasvals);
    __aliasvals = newvals;

    // Allocate bigger __aliases
    char** newalias = (char**) malloc(newcap*sizeof(char*));
    for(int i = 0; i < newcap; i++)
    {
        newalias[i] = (char*) malloc(ALIAS_LENGTH*sizeof(char*));
        if(newalias[i] == NULL)
            printf("ERROR: failed to malloc (init_path)\n");
        if(i < __alias_length)
            strcpy(newalias[i], __aliases[i]);
    }
    free(__aliases);
    __aliases = newalias;

    // Allocate bigger aliasc
    __aliasc = (int*) realloc(__aliasc, newcap*sizeof(int));

    __alias_cap = newcap;

    return 0;
}

// parse_alias_cmd converts an incorectly tokenized alias cmd and converts it into a correctly parse
// arg list, with the first item being the alias name and the subsequent values being the cmd arguments.
// Note that anything after second ' is discarded. Returns NULL on error. argc is updated with the new args
char** parse_alias_cmd(char** cmd, int* argc, char* newalias)
{
    if(*argc <= 1)
    {
        printf("Not enough cmd args\n");
        return NULL;
    }

    //init ret
    char** ret = (char**) malloc((*argc)*sizeof(char*));

    //Find split
    int split = contains(cmd[1], "='");
    if(split == -1)
    {
        printf("usage: alias <aliasname>='<command'\n");
        return NULL;
    }

    // Copy first part
    char* alias = (char*) malloc((strlen(cmd[1])+1)*sizeof(char));
    for(int i = 0; i < split; i++)
        alias[i] = cmd[1][i];
    alias[split] = '\0';
    strcpy(newalias, alias);

    // Copy second part
    char* cmd0 = malloc((strlen(cmd[1])+1)*sizeof(char));
    for(int i = split+2; i < strlen(cmd[1]); i++)
        cmd0[i-split-2] = cmd[1][i];

    // Check if second ', if so return immediately
    if(contains(cmd0, "'") != -1)
    {
        cmd0[contains(cmd0, "'")] = '\0';
        ret[0] = cmd0;
        *argc = 1;
        return ret;
    }

    bool stop = false;
    ret[0] = cmd0;
    for(int cmdi = 2; cmdi < *argc && !stop; cmdi++)
    {
        ret[cmdi-1] = cmd[cmdi];
        int stopsplit = contains(ret[cmdi-1], "'");
        if(stopsplit != -1)
        {
            stop = true;
            //copy
            char* last = (char*) malloc((stopsplit+1)*sizeof(char));
            for(int i = 0; i < stopsplit; i++)
                last[i] = ret[cmdi-1][i];
            last[stopsplit] = '\0';
            ret[cmdi-1] = last;
            *argc = cmdi;
            return ret;
        }
    }

    return NULL;
}

#undef START_CAP
#undef CAP_MULT