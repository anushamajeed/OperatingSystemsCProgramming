#include "path.h"

#define START_CAP (2)
#define CAP_MULT (2)

//Postconds:
//Any string before length is non-null
//Any string before length is terminated by \0
char** __paths;
int __path_length = 0;
int __path_cap = START_CAP;
bool __path_open = false;

// path takes in the raw cmd request, and performs as specified in the poject statement.
// Returns:
// -2: On malformed command
// <0: On error
// 0: On success.
int path(char* cmd[512], int argc)
{
    // Guards
    if(strcmp(cmd[0], PATH_CMD) != 0)
    {
        printf("ERROR: path() may have been called incorrrectly. the given command is %s, where path is expected.\n", cmd[0]);
        return -1;
    }
    if(argc != 1 && argc != 3)
    {
        printf("usage: path [+/-] <path>\nFor example, `path + /bin` adds /bin to the path.\n");
        return -2;
    }

    // Print out paths
    if(argc == 1)
    {
        printf("%s\n", sprint_path());
        return 0;
    }

    // Add or remove path
    if(strcmp(cmd[1], "+") == 0)
        return add_path(cmd[2]);
    else if(strcmp(cmd[1], "-") == 0)
        return rm_path(cmd[2]);
    else
    {
        printf("usage: path [+/-] <path>\nFor example, `path + /bin` adds /bin to the path.\n");
        return -2;
    }
}

// init_path performs memory initialization of path impl, and should be called at shell startup
int init_path()
{
    __paths = (char**) malloc(__path_cap*sizeof(char*));
    if(__paths == NULL)
        printf("ERROR: failed to malloc (init_path)\n");

    for(int i = 0; i < __path_cap; i++)
    {
        __paths[i] = (char*) malloc(PATH_LENGTH*sizeof(char*));
        if(__paths == NULL)
            printf("ERROR: failed to malloc (init_path)\n");
    }
    __path_open = true;

    return 0;
}

// uninit_path performs memory deallocation, and should be performed at shell stop
int uninit_path()
{
    __path_open = false;
    for(int i = 0; i < __path_cap; i++)
        free(__paths[i]);
    free(__paths);

    return 0;
}

// sprint_path returns a colon-separated list of paths
char* sprint_path()
{
    // Guard
    if(!__path_open)
        printf("ERROR: memory for path has been deallocated. (sprint_path)\n");
    
    // Determine Length. Could just multiply by PATH_LENGTH, but seems like a lot of wasted space
    int sum = 0;
    for(int i = 0; i < __path_length; i++)
    {
        int s = 0;
        while(__paths[i] != NULL && __paths[i][s] != '\0')
        {
            sum++;
            s++;
        }
    }

    // Copy into string
    char* ret = malloc((sum+1)*sizeof(char));
    if(ret == NULL) printf("ERROR: failed to malloc (sprint_path)\n");

    int pos = 0;
    for(int i = 0; i < __path_length; i++)
    {
        char c = '-';
        for(int s = 0; s < PATH_LENGTH && c != '\0'; s++)
        {
            c = __paths[i][s];
            if(c == '\0') {
                continue;
            }
            ret[pos] = c;
            pos++;
        }
        

        if(i != __path_length-1)
        {
            ret[pos] = ':';
            pos++;
        }
    }
    ret[pos] = '\0';
    return ret;
}

// add_path adds a path to the shell
int add_path(char* path)
{
    // Guard
    if(!__path_open)
    {
        printf("ERROR: memory for path has been deallocated. (sprint_path)\n");
        return -1;
    }
    if(strlen(path) > PATH_MAX_LEN)
    {
        printf("ERROR: length of given path is more than PATH_MAX_LEN (%d > %d)\n", strlen(path), PATH_MAX_LEN);
        return -1;
    }
    if(ensure_path_cap(__path_length+1) != 0)
    {
        printf("ERROR: failed to ensure path capacity\n");
        return -1;
    }

    // Copy new path into paths index
    __paths[__path_length] = (char*) malloc(512*sizeof(char));
	if(__paths[__path_length] == NULL) {printf("ERROR: failed to malloc, exiting"); exit(-1);}
   strcpy(__paths[__path_length], path);
   __path_length++;

   return 0;
}

// rm_path removes a path from the shell.
// Return:
// <0: On error
// 0: On successful removal
// 1: If path was not found
int rm_path(char* path)
{
    // Guard
    if(!__path_open)
    {
        printf("ERROR: memory for path has been deallocated. (sprint_path)\n");
        return -1;
    }
    if(strlen(path) > PATH_MAX_LEN)
    {
        printf("ERROR: length of given path is more than PATH_MAX_LEN (%d > %d)\n", strlen(path), PATH_MAX_LEN);
        return -1;
    }

    // Find path
    int index = -1;
    for(int i = 0; i < __path_length; i++)
    {
        if(strcmp(path, __paths[i]) == 0)
        {
            index = i;
            break;
        }
    }

    // Path wasn't found
    if(index == -1)
        return 1;
    
    // Remove path
    for(int i = index; i < __path_length - 1; i++)
        __paths[i] = __paths[i+1];
    __paths[__path_length-1] = NULL; // Necessary to zero out second same pointer, otherwise free() twice will cause issues.
    __path_length--;

    return 0;
}

// ensure_path_cap ensures that there is len indexes allocated in __paths
int ensure_path_cap(int len)
{
    if(len <= __path_cap)
        return 0;
    
    int newcap = __path_cap*CAP_MULT;

    char** newarr = (char**) malloc(newcap*sizeof(char**));
    for(int i = 0; i < newcap; i++)
    {
        newarr[i] = (char*) malloc(PATH_LENGTH*sizeof(char*));
        if(i < __path_length)
            newarr[i] = __paths[i];
    }

    // for(int i = 0; i < __path_cap; i++)
    //     free(__paths[i]);
    __paths = newarr;
    __path_cap = newcap;

    return 0;
}

#undef START_CAP
#undef CAP_MULT