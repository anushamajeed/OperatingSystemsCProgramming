#ifndef ALIAS_H
#define ALIAS_H

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define ALIAS_LENGTH (512)
#define ALIAS_MAX_LEN (ALIAS_LENGTH-1)
#define ALIAS_CMD "alias"
#define ABS_MAX (512)

int alias(char* cmd[], int argc);
int init_alias();
int uninit_alias();
char* sprint_alias();
int add_alias(char* alias, char** cmd, int cmdc);
int rm_alias(char* path);
int rm_all_alias();
int ensure_alias_cap(int len);
int contains(char* str, char* ss);
int alias_len();
char* alias_at(int i);
char** alias_translate(int i);
int aliasc(int i);

char** parse_alias_cmd(char** cmd, int* argc, char* newalias);

#endif