#ifndef TOOL_H
#define TOOL_H

#include <stdio.h>
#include <string.h>

void dump_char_arr(char** arr, int len)
{
    for(int i = 0; i < len; i++)
    {
        printf("%s\n", arr[i]);
    }
    fflush(stdout);
}

int contains(char* str, char* ss)
{
    for(int i = 0; i < strlen(str); i++)
    {
        int found = 1;
        for(int j = 0; j < strlen(ss); j++)
        {
            if(str[i+j] != ss[j])
            {
                found = 0;
                break;
            }
        }

        if(found)
            return i;
    }
    return -1;
}

#endif