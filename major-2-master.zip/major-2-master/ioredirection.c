//Anusha Majeed aam0524 io redirection
// Dinh Thang Nguyen dtn0086 pipelining

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<readline/readline.h>
#include<readline/history.h>
#include "major2.h"
#include "ioredirection.h"

// Clearing the shell using escape sequences
#define clear() printf("\033[H\033[J")

void init_shell()
{
	clear();
	printf("\n\n\n\n******************"
	"************************");
	printf("\n\n\n\t****GROUP 10 SHELL****");
	printf("\n\n\n\n*******************"
	"***********************");

	char* username = getenv("USER");
	printf("\n\n\nUSER is: @%s", username);
	printf("\n");

	sleep(1);
	clear();
}


// Function to take input
int recieveInput(char* str)
{
	char* buf;
	buf = readline("\n>>> ");

	if (strlen(buf) != 0) 
	{
		add_history(buf);
		strcpy(str, buf);	
		return 0;
	} 
	else 
	{
		return 1;
	}
}


// Function to print Current Directory.
void printDir()
{
	char cwd[1024];
	getcwd(cwd, sizeof(cwd));
	printf("\nDir: %s", cwd);
}


// Function where the system command is executed
void execArgs(char** parsed)
{
	// Forking a child
	pid_t pid = fork();

	if (pid == -1)
	{
		printf("\nFailed forking child..");
		return;
	} 
	else if (pid == 0) 
	{

		if (execvp(parsed[0], parsed) < 0) 
		{

			printf("\nCould not execute command..");

		}
		exit(0);
	} 
	else 
	{
		// waiting for child to terminate
		wait(NULL);
		return;
	}
}

// Function where the piped system with 3 commands is executed
void execArgsPiped3(char** parsed, char** parsedpipe, char** parsedpipe2)
{
    // 0 is read end, 1 is write end
    int pipefd1[2];
	int pipefd2[2];
    pid_t p1, p2, p3;

    if (pipe(pipefd1) < 0 || pipe(pipefd2) < 0) {
        printf("\nPipe could not be initialized");
        return;
    }
    p1 = fork();
    if (p1 < 0) {
        printf("\nCould not fork");
        return;
    }

    if (p1 == 0) {
        // Child 1 executing..
        // It only needs to write at the write end
        dup2(pipefd1[1], STDOUT_FILENO);
		close(pipefd1[0]);
        close(pipefd1[1]);
		close(pipefd2[0]);
    	close(pipefd2[1]);

        if (execvp(parsed[0], parsed) < 0) {
            printf("\nCould not execute command 1..");
            exit(0);
        }
    } else {
        // Parent executing
        p2 = fork();
		
        if (p2 < 0) {
            printf("\nCould not fork");
            return;
        }

        // Child 2 executing..
        // It only needs to read at the read end
        if (p2 == 0) {
            dup2(pipefd1[0], STDIN_FILENO);
			dup2(pipefd2[1], STDOUT_FILENO);
            close(pipefd1[0]);
			close(pipefd1[1]);
			close(pipefd2[0]);
			close(pipefd2[1]);
            if (execvp(parsedpipe[0], parsedpipe) < 0) {
                printf("\nCould not execute command 2..");
                exit(0);
            }
        } else {
			// Parent executing
			p3 = fork();

			if (p3 < 0) {
				printf("\nCould not fork");
				return;
			}

			// Child 3 executing..
			// It only needs to read at the read end
			if (p3 == 0) {
				dup2(pipefd2[0], STDIN_FILENO);
				close(pipefd1[0]);
				close(pipefd1[1]);
				close(pipefd2[0]);
				close(pipefd2[1]);
				if (execvp(parsedpipe2[0], parsedpipe2) < 0) {
					printf("\nCould not execute command 3..");
					exit(0);
				}
			}
        }
    }
	close(pipefd1[0]);
	close(pipefd1[1]);
	close(pipefd2[0]);
	close(pipefd2[1]);
	for (int i = 0; i < 3; i++)
	{
		wait(NULL);
	}
}

// Function where the piped system with 2 commands is executed
void execArgsPiped2(char** parsed, char** parsedpipe)
{
    // 0 is read end, 1 is write end
    int pipefd1[2];
    pid_t p1, p2;

    if (pipe(pipefd1) < 0) {
        printf("\nPipe could not be initialized");
        return;
    }
    p1 = fork();
    if (p1 < 0) {
        printf("\nCould not fork");
        return;
    }

    if (p1 == 0) {
        // Child 1 executing..
        // It only needs to write at the write end
        dup2(pipefd1[1], STDOUT_FILENO);
		close(pipefd1[0]);
        close(pipefd1[1]);

        if (execvp(parsed[0], parsed) < 0) {
            printf("\nCould not execute command 1..");
            exit(0);
        }
    } else {
        // Parent executing
        p2 = fork();
		
        if (p2 < 0) {
            printf("\nCould not fork");
            return;
        }

        // Child 2 executing..
        // It only needs to read at the read end
        if (p2 == 0) {
            dup2(pipefd1[0], STDIN_FILENO);
            close(pipefd1[0]);
			close(pipefd1[1]);
            if (execvp(parsedpipe[0], parsedpipe) < 0) {
                printf("\nCould not execute command 2..");
                exit(0);
            }
        } 
    }
	close(pipefd1[0]);
	close(pipefd1[1]);
	for (int i = 0; i < 2; i++)
	{
		wait(NULL);
	}
}

// Function to execute builtin commands
int CmdHandler(char** parsed)
{
	int CmdsAmount = 4, i, ArgSwitch = 0;
	char* CmdsList[CmdsAmount];
	char* username;

	CmdsList[0] = "exit";
	CmdsList[1] = "cd";
	CmdsList[2] = "help";
	CmdsList[3] = "hello";
	
	for (i = 0; i < CmdsAmount; i++) 
	{
		if (strcmp(parsed[0], CmdsList[i]) == 0) 
		{
			ArgSwitch = i + 1;
			break;
		}
	}


	switch (ArgSwitch) 
	{
		case 1:
			printf("\nGoodbye\n");
			exit(0);
		case 2:
			chdir(parsed[1]);
			return 1;
		default:
			break;
	}
	return 0;
}


// function for finding pipe
int parsePipe(char* str, char** strpiped)
{
	int i;
	for (i = 0; i < 3; i++) 
	{
		strpiped[i] = strsep(&str, "|");
		if (strpiped[i] == NULL)
			break;
	}
	if (strpiped[1] == NULL)
		return 0; // returns zero if no pipe is found.
	else 
	{
		if (strpiped[2] == NULL){
			return 2;
		}
		else {
			return 3;
		}
	}
}


// function for parsing command words
void parseSpace(char* str, char** parsed)
{
	int i;
	for (i = 0; i < MAXLIST; i++) 
	{
		parsed[i] = strsep(&str, " ");
		if (parsed[i] == NULL)
			break;
		if (strlen(parsed[i]) == 0)
			i--;
	}
}

int processString(char* str, char** parsed, char** parsedpipe, char** parsedpipe2)
{
	char* strpiped[3];
	int piped = 0;
	piped = parsePipe(str, strpiped);

	if (piped) 
	{
		parseSpace(strpiped[0], parsed);
		parseSpace(strpiped[1], parsedpipe);
		parseSpace(strpiped[2], parsedpipe2);
	} else 
	{
		parseSpace(str, parsed);
	}
	if (CmdHandler(parsed))
		return 0;
	else
		return 1 + piped;
}

