#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define PATH_LENGTH (100)
#define PATH_MAX_LEN (PATH_LENGTH-1)
#define PATH_CMD "path"

int path(char** cmd, int argc);
int init_path();
int uninit_path();
char* sprint_path();
int add_path(char* path);
int rm_path(char* path);
int ensure_path_cap(int len);