void init_shell();
int recieveInput(char* str);
void printDir();
void execArgs(char** parsed);
void execArgsPiped3(char** parsed, char** parsedpipe, char** parsedpipe2);
void execArgsPiped2(char** parsed, char** parsedpipe);
int CmdHandler(char** parsed);
int parsePipe(char* str, char** strpiped);
void parseSpace(char* str, char** parsed);
int processString(char* str, char** parsed, char** parsedpipe, char** parsedpipe2);

#define MAXCOM 1000 // max number of letters to be supported
#define MAXLIST 100 // max number of commands to be supported
