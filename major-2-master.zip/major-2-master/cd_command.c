//Anusha Majeed aam0524 cd command
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include "major2.h"
#include "cd_command.h"
#define BUF_SIZE 300



int prex(char const *p, char const *q)
{
	int i = 0;
	for(i = 0;q[i];i++)
	{
		if(p[i] != q[i])
			return -1;
	}
	return 0;
}

int cd(char *pth[512])
{
	if(pth[1] == NULL)
	{
		chdir(getenv("HOME"));
	}
	else
	{
		chdir(pth[1]);
	}
	return 0;
}
